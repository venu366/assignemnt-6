TRAINING_BUCKET_NAME = "sensor-model"
PREDICTION_BUCKET_NAME = "sensor-datasource"