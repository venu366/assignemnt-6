DATABASE_NAME = "ineuron"
COLLECTION_NAME = "sensor"